package objRepository;

public class ObjectRepository {
	
	//Login
	public static String txtUserName="userName";
	public static String txtPassword="//input[@name='password']";
	public static String btnLogin="login";
	
	//Logged in page
	public static String lnkSignOff="SIGN-OFF";

}
