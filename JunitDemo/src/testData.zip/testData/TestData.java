package testData;

public class TestData {
 public static String AppURL="http://newtours.demoaut.com/";
 public static String userName="mercury";
 public static String password="mercury";
 public static String expPageTitle="Welcome: Mercury Tours";
}
